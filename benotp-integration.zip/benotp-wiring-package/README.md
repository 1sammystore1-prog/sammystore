# BenOTP Integration - File Package

Every file here mirrors its path in your project (e.g. `lib/benotp.ts` goes to
`sammystore-main/lib/benotp.ts`). Extract this into your project root and it
drops straight into place.

## New files
- `lib/benotp.ts` - BenOTP integration, numbers only, all 4 pools (USA Server 1/2, All Countries 1/2)
- `components/BenotpServerGrid.tsx` - the tile-grid UI matching your reference screenshot
- `app/api/numbers/benotp/buy/route.ts`
- `app/api/numbers/benotp/cancel/route.ts`
- `app/api/numbers/benotp/status/route.ts`

## Modified files (originals are overwritten - see terminal commands for backup)
- `lib/pricing.ts` - added `getBenotpPrices()` / `invalidateBenotpPriceCache()`
- `models/PricingSettings.ts` - added `benotpPrices` field (flat NGN price per pool)
- `app/api/admin/pricing/route.ts` - now also saves/returns BenOTP flat prices
- `app/numbers/page.tsx` - added a TigerSMS/BenOTP provider tab; TigerSMS flow is untouched
- `app/admin/page.tsx` - added a BenOTP flat-price editor in the Pricing tab

## You still need to do this manually
Add your BenOTP API key to `.env.local`:

```
BENOTP_API_KEY=your_actual_key_here
```

## Known assumption to verify
`lib/benotp.ts` assumes BenOTP's getNumber/getStatus/cancel responses follow
the same bare-string SMS-Activate convention as TigerSMS
(`ACCESS_NUMBER:id:number`, `STATUS_OK:code`, etc.), since the Postman
collection didn't include example response bodies. Every BenOTP call logs
its raw response server-side (`console.log('[BenOTP:<pool>] ...')`), so if
something misbehaves, check your Vercel logs first - that'll show exactly
what BenOTP actually sent back, and the parsing can be corrected precisely
instead of guessed at again.
