import axios from 'axios';

const BASE_URL = 'https://www.danotp.com.ng/stubs/buy-accounts.php';

export async function buyAccountsRequest(action: string, params: Record<string, any> = {}) {
  const apiKey = process.env.YOUR_DANOTP_API_KEY;

  if (!apiKey) {
    throw new Error('API key not configured');
  }

  const response = await axios.get(BASE_URL, {
    params: {
      action,
      api_key: apiKey,
      ...params
    }
  });

  const data = response.data;

  // DaNotp returns HTTP 200 even when a request fails (insufficient
  // balance, out of stock, invalid product, etc.) - the failure only shows
  // up INSIDE the JSON body. Axios has no way to know that on its own, so
  // without this check a failed purchase would look identical to a
  // successful one and get reported to the customer as "Purchase
  // successful!" while their wallet was already debited for nothing.
  if (data && typeof data === 'object') {
    const status = typeof data.status === 'string' ? data.status.toLowerCase() : null;
    const looksLikeFailure =
      data.success === false ||
      status === 'error' ||
      status === 'failed' ||
      status === 'fail' ||
      (typeof data.error === 'string' && data.error.length > 0);

    if (looksLikeFailure) {
      const providerMessage =
        data.message || data.error || data.status || 'Provider declined the request';
      throw new Error(String(providerMessage));
    }
  }

  return data;
}
