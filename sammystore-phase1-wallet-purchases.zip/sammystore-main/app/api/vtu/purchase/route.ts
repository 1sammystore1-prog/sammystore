import { NextResponse } from 'next/server';
import { clubkonnectRequest } from '@/lib/clubkonnect';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Transaction from '@/models/Transaction';
import { getUserId } from '@/lib/auth';

export async function POST(request: Request) {
  await dbConnect();
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ error: 'Please login' }, { status: 401 });

  const { service_type, network, phone, amount, plan_id } = await request.json();

  const user = await User.findById(userId);
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  if (user.suspended) {
    return NextResponse.json({ error: 'Your account is suspended. Contact support.' }, { status: 403 });
  }

  try {
    // Get plan price
    const plans = await clubkonnectRequest('/plans', { type: service_type, network });
    const plan = plans.find((p: any) => p.id === plan_id);
    
    if (!plan) {
      return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });
    }

    const price = parseFloat(String(plan.price));
    if (isNaN(price) || price <= 0) {
      return NextResponse.json({ error: 'Invalid plan price' }, { status: 400 });
    }

    // Atomic check-and-deduct - avoids the race where two concurrent
    // requests both read the same balance before either writes.
    const debited = await User.findOneAndUpdate(
      { _id: userId, walletBalance: { $gte: price } },
      { $inc: { walletBalance: -price } },
      { new: true }
    );

    if (!debited) {
      return NextResponse.json({ error: 'Insufficient funds' }, { status: 400 });
    }

    // Purchase
    let purchase;
    try {
      purchase = await clubkonnectRequest('/purchase', {
        service_type,
        network,
        phone,
        plan_id,
        request_id: Date.now().toString()
      });
    } catch (purchaseError: any) {
      // Refund the already-debited balance since the purchase never went through
      await User.findByIdAndUpdate(userId, { $inc: { walletBalance: price } });
      return NextResponse.json({ success: false, error: purchaseError.message || 'Purchase failed' }, { status: 400 });
    }

    // This previously had no transaction record at all - every VTU
    // purchase debited the wallet with zero audit trail.
    try {
      await Transaction.create({
        userId,
        type: 'vtu',
        description: `${service_type} - ${network} - ${phone}`,
        amount: price,
        status: 'success'
      });
    } catch (txError) {
      console.error('Failed to record VTU transaction after successful purchase:', txError);
      // Purchase already succeeded and can't be undone at this point, so
      // don't refund here - just log loudly so it can be reconciled.
    }

    return NextResponse.json({ 
      success: true, 
      message: 'Purchase successful',
      newBalance: debited.walletBalance
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
