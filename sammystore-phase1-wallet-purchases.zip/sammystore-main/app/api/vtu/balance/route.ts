import { NextResponse } from 'next/server';
import { clubkonnectRequest } from '@/lib/clubkonnect';
import { verifyAdmin } from '@/lib/adminAuth';

export async function GET(request: Request) {
  // This returns the PLATFORM's own provider account balance (business
  // financial info), not a user's wallet balance - it had no auth check
  // at all, meaning anyone could see how much money is in the platform's
  // Clubkonnect account.
  const admin = await verifyAdmin(request);
  if (!admin) return NextResponse.json({ success: false, error: 'Forbidden' }, { status: 403 });

  try {
    const data = await clubkonnectRequest('/balance');
    return NextResponse.json({ success: true, balance: data });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
