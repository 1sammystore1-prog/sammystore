import { NextResponse } from 'next/server';
import { japRequest } from '@/lib/jap';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Transaction from '@/models/Transaction';
import { getUserId } from '@/lib/auth';

export async function POST(request: Request) {
  await dbConnect();
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ error: 'Please login' }, { status: 401 });

  const { service, link, quantity } = await request.json();

  const user = await User.findById(userId);
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  if (user.suspended) {
    return NextResponse.json({ error: 'Your account is suspended. Contact support.' }, { status: 403 });
  }

  try {
    // Get service price first
    const services = await japRequest('services');
    const selectedService = services.find((s: any) => s.service === parseInt(service));
    
    if (!selectedService) {
      return NextResponse.json({ error: 'Invalid service' }, { status: 400 });
    }

    // Calculate cost
    const cost = (selectedService.rate * quantity) / 1000;
    if (isNaN(cost) || cost <= 0) {
      return NextResponse.json({ error: 'Invalid cost calculation' }, { status: 400 });
    }

    // Atomic check-and-deduct - avoids the race where two concurrent
    // requests both read the same balance before either writes.
    const debited = await User.findOneAndUpdate(
      { _id: userId, walletBalance: { $gte: cost } },
      { $inc: { walletBalance: -cost } },
      { new: true }
    );

    if (!debited) {
      return NextResponse.json({ error: 'Insufficient funds' }, { status: 400 });
    }

    // Place order
    let order;
    try {
      order = await japRequest('add', {
        service,
        link,
        quantity: quantity.toString()
      });
    } catch (orderError: any) {
      // Refund the already-debited balance since the order never went through
      await User.findByIdAndUpdate(userId, { $inc: { walletBalance: cost } });
      return NextResponse.json({ success: false, error: orderError.message || 'Order failed' }, { status: 400 });
    }

    // This previously had no transaction record at all - every SMM order
    // debited the wallet with zero audit trail.
    try {
      await Transaction.create({
        userId,
        type: 'smm',
        description: `SMM order: service ${service} - qty ${quantity}`,
        amount: cost,
        status: 'success'
      });
    } catch (txError) {
      console.error('Failed to record SMM transaction after successful order:', txError);
    }

    return NextResponse.json({ 
      success: true, 
      orderId: order.order,
      newBalance: debited.walletBalance
    });
  } catch (error: any) {
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}
