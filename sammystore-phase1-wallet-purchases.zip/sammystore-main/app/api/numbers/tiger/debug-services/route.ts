import { NextResponse } from 'next/server';
import axios from 'axios';

// TEMPORARY DEBUG ROUTE - safe to delete once the service-name issue is
// diagnosed. Calls getServicesList directly and returns the raw response
// plus some shape diagnostics, so we can see exactly what Tiger-SMS sends
// back without digging through server logs.
export const dynamic = 'force-dynamic';

export async function GET() {
  const apiKey = process.env.TIGER_SMS_API_KEY;

  if (!apiKey) {
    return NextResponse.json({ error: 'TIGER_SMS_API_KEY not set' }, { status: 500 });
  }

  try {
    const url = new URL('https://api.tiger-sms.com/stubs/handler_api.php');
    url.searchParams.set('api_key', apiKey);
    url.searchParams.set('action', 'getServicesList');
    url.searchParams.set('lang', 'en');

    const res = await axios.get(url.toString(), {
      timeout: 10000,
      validateStatus: () => true
    });

    const data = res.data;

    return NextResponse.json({
      httpStatus: res.status,
      dataType: typeof data,
      isArray: Array.isArray(data),
      hasServicesKey: typeof data === 'object' && data !== null && 'services' in data,
      servicesIsArray: Array.isArray(data?.services),
      servicesLength: Array.isArray(data?.services) ? data.services.length : null,
      firstThreeServices: Array.isArray(data?.services) ? data.services.slice(0, 3) : null,
      rawData: data
    });
  } catch (error: any) {
    return NextResponse.json({
      success: false,
      error: error.message,
      status: error.response?.status,
      data: error.response?.data
    }, { status: 500 });
  }
}
