import { NextResponse } from 'next/server';
import { getBalance } from '@/lib/tigerSms';
import { verifyAdmin } from '@/lib/adminAuth';

export const dynamic = 'force-dynamic';

export async function GET(request: Request) {
  // This returns the PLATFORM's own TigerSMS provider account balance
  // (business financial info), not a user's wallet balance - it had no
  // auth check at all.
  const admin = await verifyAdmin(request);
  if (!admin) return NextResponse.json({ success: false, error: 'Forbidden' }, { status: 403 });

  try {
    const balance = await getBalance();
    return NextResponse.json({ success: true, balance });
  } catch (e: any) {
    console.error('Get balance error:', e);
    return NextResponse.json(
      { success: false, error: e.message || 'Failed to get balance' },
      { status: 500 }
    );
  }
}
