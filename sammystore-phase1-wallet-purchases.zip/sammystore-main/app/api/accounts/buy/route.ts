import { NextResponse } from 'next/server';
import { buyAccountsRequest } from '@/lib/buyaccounts';
import { getUserId } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Transaction from '@/models/Transaction';

// Extract a flat product list the same way /api/accounts/products does,
// so both routes agree on where prices actually live in the provider's
// response shape.
function extractProducts(data: any): any[] {
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object') {
    if (Array.isArray(data.categories)) {
      const products: any[] = [];
      data.categories.forEach((category: any) => {
        if (Array.isArray(category.products)) products.push(...category.products);
      });
      return products;
    }
    if (Array.isArray(data.products)) return data.products;
    if (data.product && typeof data.product === 'object') return [data.product];
  }
  return [];
}

export async function POST(request: Request) {
  await dbConnect();
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ success: false, error: 'Please login' });

  const { productId, amount, coupon } = await request.json();
  const qty = parseInt(String(amount)) || 1;

  const user = await User.findById(userId);
  if (!user) return NextResponse.json({ success: false, error: 'User not found' });

  if (user.suspended) {
    return NextResponse.json({ success: false, error: 'Your account is suspended. Contact support.' });
  }

  // SECURITY: price previously came straight from the request body, so a
  // user could send any number they wanted for `price` and pay that
  // instead of the product's real cost. Look it up server-side from the
  // same catalog /api/accounts/products uses instead.
  let unitPrice: number;
  try {
    const productsData = await buyAccountsRequest('getProducts');
    const products = extractProducts(productsData);
    const product = products.find((p: any) => String(p.id) === String(productId));
    if (!product) {
      return NextResponse.json({ success: false, error: 'Product not found' });
    }
    unitPrice = parseFloat(String(product.price));
    if (isNaN(unitPrice) || unitPrice <= 0) {
      return NextResponse.json({ success: false, error: 'Invalid product price' });
    }
  } catch (e) {
    return NextResponse.json({ success: false, error: 'Could not verify product price' });
  }

  const cost = unitPrice * qty;
  if (isNaN(cost) || cost <= 0) {
    return NextResponse.json({ success: false, error: 'Invalid cost calculation' });
  }

  // Atomic check-and-deduct - the previous read-then-write pattern let two
  // concurrent requests both pass the balance check before either wrote,
  // letting a user spend more than they actually had.
  const debited = await User.findOneAndUpdate(
    { _id: userId, walletBalance: { $gte: cost } },
    { $inc: { walletBalance: -cost } },
    { new: true }
  );

  if (!debited) {
    return NextResponse.json({ success: false, error: 'Insufficient funds' });
  }

  try {
    const data = await buyAccountsRequest('buyProduct', {
      id: productId,
      amount: qty,
      coupon: coupon || ''
    });

    await Transaction.create({
      userId,
      type: 'account_purchase',
      description: `Bought account ID ${productId}`,
      amount: cost,
      status: 'success'
    });

    return NextResponse.json({
      success: true,
      message: 'Purchase successful!',
      accountData: data,
      newBalance: debited.walletBalance
    });
  } catch (error) {
    // Refund on failure
    await User.findByIdAndUpdate(userId, { $inc: { walletBalance: cost } });
    return NextResponse.json({ success: false, error: 'Purchase failed' });
  }
}
