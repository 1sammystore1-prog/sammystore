import { NextResponse } from 'next/server';
import dbConnect from '@/lib/mongodb';
import Transaction from '@/models/Transaction';
import { getUserId } from '@/lib/auth';

// This route previously had no auth check, never touched the database,
// and unconditionally returned success - meaning it silently did nothing
// while telling the user their fund request was submitted. It's currently
// unreferenced by any frontend page, but fixed to actually behave
// correctly (same as /api/fund/request) rather than leave a landmine for
// whoever wires it up next.
export async function POST(request: Request) {
  try {
    await dbConnect();
    const userId = getUserId(request);
    if (!userId) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });

    const { amount, reference } = await request.json();
    const validAmount = parseFloat(String(amount));
    if (isNaN(validAmount) || validAmount <= 0) {
      return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
    }

    await Transaction.create({
      userId,
      type: 'manual_fund_request',
      description: `Manual Transfer Request for ₦${validAmount}${reference ? ` (ref: ${reference})` : ''}`,
      amount: validAmount,
      status: 'pending'
    });

    return NextResponse.json({
      success: true,
      message: 'Manual transfer request submitted. Admin will verify.'
    });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Server Error' }, { status: 500 });
  }
}
