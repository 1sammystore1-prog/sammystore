import { NextResponse } from 'next/server';
import axios from 'axios';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Transaction from '@/models/Transaction';
import { getUserId } from '@/lib/auth';

export async function POST(request: Request) {
  await dbConnect();
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { type, reference } = await request.json();

  // SECURITY: this route previously trusted a client-supplied `amount` and
  // credited the wallet directly with zero payment verification - any
  // logged-in user could POST any amount and instantly credit themselves.
  // It's now split into the only two legitimate paths:
  //
  // 1. 'paystack' - verify the payment really happened via Paystack's own
  //    server-side verify API, and credit exactly what Paystack confirms
  //    was paid (never a client-supplied number).
  // 2. 'manual' - this must go through admin review; instant-crediting a
  //    manual bank transfer claim with no proof was the same class of bug.
  //    Use /api/fund/request instead, which creates a pending transaction
  //    for an admin to approve via /api/admin/approve-fund.

  if (type === 'manual') {
    return NextResponse.json(
      { error: 'Manual funding must be submitted via the fund request flow for admin approval' },
      { status: 400 }
    );
  }

  if (type !== 'paystack') {
    return NextResponse.json({ error: 'Unsupported funding type' }, { status: 400 });
  }

  if (!reference || typeof reference !== 'string') {
    return NextResponse.json({ error: 'Payment reference required' }, { status: 400 });
  }

  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) {
    return NextResponse.json({ error: 'Payment verification is not configured' }, { status: 500 });
  }

  let verifyRes;
  try {
    verifyRes = await axios.get(
      `https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`,
      { headers: { Authorization: `Bearer ${secretKey}` }, timeout: 10000 }
    );
  } catch (e: any) {
    return NextResponse.json(
      { error: 'Could not verify payment with Paystack' },
      { status: 502 }
    );
  }

  const paystackData = verifyRes.data?.data;
  if (!paystackData || paystackData.status !== 'success') {
    return NextResponse.json({ error: 'Payment was not successful' }, { status: 400 });
  }

  // Confirm this payment actually belongs to the requesting user, not just
  // any successful Paystack transaction reference someone happened to pass.
  if (String(paystackData.metadata?.userId) !== String(userId)) {
    return NextResponse.json({ error: 'This payment does not belong to your account' }, { status: 403 });
  }

  // Paystack amounts are in kobo; convert to naira, and always use
  // Paystack's own confirmed amount - never anything the client sent.
  const verifiedAmount = paystackData.amount / 100;

  // Create the transaction record first with the reference as a unique
  // key: if this reference was already used to fund a wallet, the unique
  // index on paystackReference makes this insert fail, so the same
  // payment can never credit the wallet twice (replay protection).
  try {
    await Transaction.create({
      userId,
      type: 'wallet_fund',
      description: `Wallet funded via Paystack (ref: ${reference})`,
      amount: verifiedAmount,
      status: 'success',
      paystackReference: reference
    });
  } catch (e: any) {
    if (e?.code === 11000) {
      return NextResponse.json({ error: 'This payment has already been credited' }, { status: 409 });
    }
    throw e;
  }

  const updated = await User.findByIdAndUpdate(
    userId,
    { $inc: { walletBalance: verifiedAmount } },
    { new: true }
  );

  return NextResponse.json({ success: true, newBalance: updated?.walletBalance });
}
