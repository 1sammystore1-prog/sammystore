import { NextResponse } from 'next/server';
import axios from 'axios';
import { getUserId } from '@/lib/auth';

export async function POST(request: Request) {
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ success: false, error: 'Unauthorized' }, { status: 401 });

  try {
    const { email, amount } = await request.json();
    const secretKey = process.env.PAYSTACK_SECRET_KEY;

    if (!secretKey) return NextResponse.json({ success: false, error: 'Paystack key missing' });

    const validAmount = parseFloat(String(amount));
    if (isNaN(validAmount) || validAmount <= 0) {
      return NextResponse.json({ success: false, error: 'Invalid amount' }, { status: 400 });
    }

    // Call Paystack to initialize transaction. metadata.userId always comes
    // from the authenticated session, never the request body - the later
    // verify step in /api/wallet/add-funds trusts this field to confirm a
    // payment belongs to the crediting user, so it must not be spoofable.
    const response = await axios.post('https://api.paystack.co/transaction/initialize', {
      email: email,
      amount: validAmount * 100, // Paystack uses kobo
      reference: `SAMMY-${Date.now()}`,
      metadata: { userId: String(userId) }
    }, {
      headers: { Authorization: `Bearer ${secretKey}` }
    });

    return NextResponse.json({ success: true, url: response.data.data.authorization_url });
  } catch (error) {
    return NextResponse.json({ success: false, error: 'Payment initialization failed' });
  }
}
