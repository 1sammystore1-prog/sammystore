import { NextResponse } from 'next/server';
import { verifyAdmin } from '@/lib/adminAuth';
import dbConnect from '@/lib/mongodb';
import Transaction from '@/models/Transaction';
import User from '@/models/User';

export async function POST(request: Request) {
  // This route credits a user's wallet based on a manual fund request -
  // without an admin check, ANY authenticated user could call this
  // directly with their own (or anyone else's) pending transactionId and
  // get instantly credited, without an admin ever verifying the claimed
  // payment actually happened. This was missing entirely.
  const admin = await verifyAdmin(request);
  if (!admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 });

  await dbConnect();
  const { transactionId } = await request.json();

  const txn = await Transaction.findById(transactionId);
  if (!txn || txn.status !== 'pending' || txn.type !== 'manual_fund_request') {
    return NextResponse.json({ error: 'Invalid transaction' }, { status: 400 });
  }

  // Update transaction status
  txn.status = 'success';
  await txn.save();

  // Add money to user's wallet
  const user = await User.findById(txn.userId);
  if (user) {
    user.walletBalance = (user.walletBalance || 0) + txn.amount;
    await user.save();
  }

  return NextResponse.json({ success: true, message: 'Funds approved' });
}
