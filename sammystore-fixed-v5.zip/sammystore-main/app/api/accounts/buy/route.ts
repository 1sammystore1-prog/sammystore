import { NextResponse } from 'next/server';
import { purchaseListing, getAllListings } from '@/lib/accszone';
import { getUserId } from '@/lib/auth';
import dbConnect from '@/lib/mongodb';
import User from '@/models/User';
import Transaction from '@/models/Transaction';
import { getMarkups, computeMarkup, toNgn } from '@/lib/pricing';

// buyacc1 (AccsZone) only now - buyacc2 (HStora) purchases go through
// /api/logs/buy instead, matching the /accounts vs /logs page split.
export async function POST(request: Request) {
  await dbConnect();
  const userId = getUserId(request);
  if (!userId) return NextResponse.json({ success: false, error: 'Please login' }, { status: 401 });

  const { productId, amount, coupon } = await request.json();
  const qty = parseInt(String(amount)) || 1;
  if (!productId || qty <= 0) {
    return NextResponse.json({ success: false, error: 'Invalid request' }, { status: 400 });
  }

  const idStr = String(productId);
  if (!idStr.startsWith('buyacc1_')) {
    return NextResponse.json({ success: false, error: 'Unknown product source' }, { status: 400 });
  }
  const rawId = idStr.replace(/^buyacc1_/, '');

  const user = await User.findById(userId);
  if (!user) return NextResponse.json({ success: false, error: 'User not found' }, { status: 404 });
  if (user.suspended) {
    return NextResponse.json({ success: false, error: 'Your account is suspended. Contact support.' }, { status: 403 });
  }

  const listings = await getAllListings();
  const listing = listings.find((l: any) => String(l.id) === String(rawId));

  if (!listing) {
    return NextResponse.json({ success: false, error: 'Product not found' }, { status: 400 });
  }

  if (typeof listing.available_stock === 'number' && listing.available_stock <= 0) {
    return NextResponse.json({ success: false, error: 'This product is out of stock' }, { status: 400 });
  }
  if (typeof listing.available_stock === 'number' && qty > listing.available_stock) {
    return NextResponse.json(
      { success: false, error: `Only ${listing.available_stock} available - please lower the quantity` },
      { status: 400 }
    );
  }

  const baseUnitPriceUsd = parseFloat(String(listing.price));
  if (isNaN(baseUnitPriceUsd) || baseUnitPriceUsd <= 0) {
    return NextResponse.json({ success: false, error: 'Invalid product price' }, { status: 500 });
  }

  const markups = await getMarkups();
  const unitPrice = computeMarkup(toNgn(baseUnitPriceUsd), markups.accounts);
  const cost = unitPrice * qty;

  const debited = await User.findOneAndUpdate(
    { _id: userId, walletBalance: { $gte: cost } },
    { $inc: { walletBalance: -cost } },
    { new: true }
  );

  if (!debited) {
    return NextResponse.json({ success: false, error: 'Insufficient funds' }, { status: 400 });
  }

  try {
    const result = await purchaseListing(rawId, qty, coupon || undefined);

    const accountData =
      result.accounts.length === 1
        ? { Account: result.accounts[0] }
        : Object.fromEntries(result.accounts.map((acc, i) => [`Account ${i + 1}`, acc]));

    const txn = await Transaction.create({
      userId,
      type: 'account_purchase',
      description: `Bought ${qty} x ${listing.title}`,
      amount: cost,
      status: 'success',
      metadata: {
        productId,
        source: 'buyacc1',
        productName: listing.title,
        category: listing.subcategory?.title || listing.category?.title || null,
        quantity: qty,
        accountData,
      },
    });

    return NextResponse.json({
      success: true,
      message: 'Purchase successful!',
      accountData,
      newBalance: debited.walletBalance,
      orderId: String(txn._id),
    });
  } catch (providerError: any) {
    await User.findByIdAndUpdate(userId, { $inc: { walletBalance: cost } });
    console.error('AccsZone purchase failed:', providerError?.message || providerError);
    return NextResponse.json(
      { success: false, error: 'This item could not be delivered right now - your wallet has been refunded.' },
      { status: 400 }
    );
  }
}
